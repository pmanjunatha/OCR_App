package com.cms.OCR;

import java.io.File;
import java.io.PrintStream;

import net.sourceforge.tess4j.Tesseract;

public class OcrReader
{
    public static void main( String[] args ) throws Exception {
        String inputFilePath = "C:\\Program Files (x86)\\Tesseract-OCR\\handeng.jpg";
        String output_file="C:\\Users\\Dell\\Downloads\\rohit.txt";
        Tesseract tesseract = new Tesseract();
        tesseract.setDatapath("C:\\Program Files (x86)\\Tesseract-OCR\\");
        tesseract.setLanguage("eng");
        
        String fullText = tesseract.doOCR(new File(inputFilePath));
        
        System.out.println(fullText);
        try {
        	PrintStream myconsole = new PrintStream(output_file);
        	System.setOut(myconsole);
        	myconsole.print(fullText);
        }
        catch(Exception ex) {
        	ex.printStackTrace();
    }
}
}
